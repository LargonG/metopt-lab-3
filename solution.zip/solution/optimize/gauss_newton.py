import numpy as np
import time
import sys
from numpy.linalg import inv, norm

from solution.tests import ProcInfo


def gauss_newton(func, jacobian, start, eps, max_iter):
    trace = [start]
    actions = 0
    start_time = time.time()

    param = np.array(start)
    for i in range(max_iter):
        old_param = param

        J = jacobian(param)

        d = inv(J.transpose() @ J) @ J.transpose() @ func(param)
        param = old_param - d  # NOTE: + -- if regression else -

        trace.append(param)
        actions += (len(J) * len(J[0])) ** 2 + len(J) * len(J[0])

        if norm(d) < eps:
            break

    end_time = time.time()
    return param, ProcInfo(time=end_time - start_time,
                           memory=sys.getsizeof(trace),
                           points=trace,
                           arithmetic=actions
                           )
